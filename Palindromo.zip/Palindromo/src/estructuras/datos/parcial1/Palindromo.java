package estructuras.datos.parcial1;

import fes.aragon.utilerias.dinamicas.pila.Pila;

public class Palindromo {
	public static void main(String[] args) throws Exception {
		String cad = "ana", cad2 = "";
		int partes, residuo, num = 3;
		int longitud, indice = 0;
		Pila<String> pila = new Pila<>();
		longitud = cad.length();
		partes = longitud / num;
		residuo = longitud % num;
		// System.out.println("longitud de la cadena: "+longitud+" p: "+partes+" R:
		// "+residuo);

		String[] lista = cad.split(" ");
		for (int i = 0; i < lista.length; i++) {
			System.out.println(lista[i]);
			cad2 += lista[i];
		}

		System.out.println("cad2: " + cad2);
		String sep[] = new String[cad2.length()];
		System.out.print("sep: ");
		for (int i = 0; i < cad2.length(); i++) {
			sep[i] = String.valueOf(cad2.charAt(indice));
			System.out.print(sep[i] + " ");
			indice++;
		}
		System.out.println();
		int j = 0, k = 0;
		pila.borrar();
//		System.out.print("pila: ");
		while (j < sep.length) {
			pila.insertar(sep[j]);
//			System.out.print(pila.extraer() + " ");
			j++;
		}
//		System.out.println(cad2);
		for (int i = 0; i < cad2.length(); i++) {
			System.out.print("pila: " + pila.extraer());
			if (cad2.equals(pila.elementoSuperior())) {
				System.out.println("*");
			} else {
				System.out.println("-");
			}
		}
//		while (pila.estaVacia()) {
//			System.out.println(k + " Hola: " + pila.elementoSuperior());
//			k++;
//		}
//		for (int i = 0; i < sep.length; i++) {
//			if (sep[i].equals(pila.elementoSuperior())) {
//				System.out.println("pila: " + pila.extraer());
//			} else {
//
//			}
//		}

//		if (pila.estaVacia()) {
//			System.out.println("es un palindromo");
//		} else {
//			System.out.println("No es un palindromo");
//		}

		/*
		 * for(int i =0; i<partes; i++) { System.out.print("Grupo " +(i+1) +": ");
		 * 
		 * for(int j =0; j<num; j++) { System.out.print(cad.charAt(indice)); indice++; }
		 * System.out.println(); }
		 */
	}
}
